<template>
<div>
  <h1>33333333333333333</h1>
</div>
</template>

<script>
/*import VCounter from '../../components/base/counter'
import VMulChooser from '../../components/base/multiplyChooser'*/
export default {

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
