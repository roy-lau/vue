<template>
<div>
  <h1>2222222222222222</h1>
</div>
</template>

<script>
/*import VSelection from '../../components/base/selection'
import VChooser from '../../components/base/chooser'*/
export default {

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
