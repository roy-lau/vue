<template>
  <div>
    <h1>4444444444444</h1>
  </div>
</template>

<script>
/*import VSelection from '../../components/base/selection'
import VCounter from '../../components/base/counter'
import VMulChooser from '../../components/base/multiplyChooser'*/
export default {

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>

</style>
