# shopping

> shopping webapp

## Build Setup

``` bash
# Download this item
1. git clone git@github.com:roy-lau/vue.git
2. cd vue/Demo/shopping

# install dependencies
3. npm install

# serve with hot reload at localhost:8080
4. npm run dev

# build for production with minification
5. npm run build

# build for production and view the bundle analyzer report
6. npm run build --report
```